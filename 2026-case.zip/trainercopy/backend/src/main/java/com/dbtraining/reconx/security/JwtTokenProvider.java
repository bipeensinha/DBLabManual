package com.dbtraining.reconx.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

/**
 * ============================================================================
 * JwtTokenProvider (jjwt 0.12.x API)
 *
 * WHAT:    Generates + validates HS256-signed JWTs.
 * HOW:     Subject = email. Role goes into a custom "role" claim that
 *          {@link JwtAuthenticationFilter} turns into a GrantedAuthority.
 * WHY:     Self-contained (no DB hit per request) and stateless (no session).
 * OBSERVE: Decode any token at jwt.io with the configured secret.
 * ============================================================================
 */
@Component
public class JwtTokenProvider {

    private final SecretKey key;
    private final long expirationMinutes;
    private final String issuer;

    public JwtTokenProvider(@Value("${reconx.security.jwt.secret}") String secret,
                            @Value("${reconx.security.jwt.expiration-minutes}") long expirationMinutes,
                            @Value("${reconx.security.jwt.issuer}") String issuer) {
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.expirationMinutes = expirationMinutes;
        this.issuer = issuer;
    }

    public String generate(String email, String role) {
        Instant now = Instant.now();
        Instant exp = now.plusSeconds(expirationMinutes * 60);
        return Jwts.builder()
                .subject(email)
                .issuer(issuer)
                .issuedAt(Date.from(now))
                .expiration(Date.from(exp))
                .claims(Map.of("role", role))
                .signWith(key)
                .compact();
    }

    public Claims parse(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .requireIssuer(issuer)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public long expirationSeconds() { return expirationMinutes * 60; }
}
