import logo from './logo.svg';
import './App.css';
import { Button } from 'reactstrap';
import { ToastContainer,toast} from 'react-toastify';

function App() {
  
  const btnHandle = () => {
    // toast ("This is demo");
    toast.success("done");
  };
  return (
    <div>
      <ToastContainer />
        <h1>This program developed by bipeen</h1>
        <Button color="primary" onClick={btnHandle}> Submit</Button>
    </div>
  /*  <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div> */
  );
}

export default App;
