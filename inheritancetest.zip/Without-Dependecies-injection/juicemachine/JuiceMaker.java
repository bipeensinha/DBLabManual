public class JuiceMaker
{

    private Fruit fruit;

    public JuiceMaker(Fruit fruit) 
    {
                this.fruit = fruit;
    }

    public void makeJuice() 
    {
        System.out.println("Juice made from " + fruit.getName());
            }
}

        