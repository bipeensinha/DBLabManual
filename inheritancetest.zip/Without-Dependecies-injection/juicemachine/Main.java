 public class Main
 {   
    public static void main(String[] args) 
    {
        Fruit apple = new Fruit("Apple");
        JuiceMaker jm = new JuiceMaker(apple); // DI in action!
        jm.makeJuice();
    }

}