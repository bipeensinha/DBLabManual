class Animal
{

    void sound()
    {
        System.out.println("Animal Makes a Sound");
    }
}

class Dog extends Animal
{

    void bark()
    {
        System.out.println("Dog Bark");
    }
}

class Cat extends Dog
{

    void meow()
    {
        System.out.println("Cat Say Meow Meow");
    }
}
public class inheritancetest 
{
    public static void main (String[] args)

    {
        Cat mycat = new Cat();
        mycat.sound();
        mycat.bark();
        mycat.meow();
    }
}