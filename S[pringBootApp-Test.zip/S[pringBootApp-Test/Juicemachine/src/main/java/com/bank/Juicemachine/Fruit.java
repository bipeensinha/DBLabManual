package com.bank.Juicemachine;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Fruit {

    private final String name;

    public Fruit (@Value("${fruit.name}") String name)
    {
        this.name =name;
    }
    public String getName()
    {
        return name;
    }
}
