package com.bank.Juicemachine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuicemachineApplicationTests {

	@Test
	void contextLoads() {
	}

}
