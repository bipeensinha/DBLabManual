package com.bank.BipApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BipAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BipAppApplication.class, args);
	}

}
