class Animal {
    void sound() {
        System.out.println("Generic animal sound");
    }
}

class Dog extends Animal {
    @Override
    void sound() {
        System.out.println("Dog barks");
    }
}

public class TestOverridingMethods {
    public static void main(String[] args) {
        Animal animal = new Dog();  // Dynamic binding
        animal.sound();             // Calls Dog's version
    }
}
