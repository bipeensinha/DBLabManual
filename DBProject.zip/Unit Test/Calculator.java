public class Calculator
{

public int add(int a, int b) {
        return a + b;
    }

    // Method to subtract two numbers
    public int subtract(int a, int b)
{
return a - b;
}

}