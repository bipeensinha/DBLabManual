class Animal {
    Animal() {
        System.out.println("Animal constructor called");
    }
}

class Dog extends Animal {
    Dog() {
        System.out.println("Dog constructor called");
    }
}

public class TestConstructorInheritance {
    public static void main(String[] args) {
        Dog dog = new Dog();  // Calls both constructors
    }
}
