package com.example.demoAnnotation.config;

import com.example.demoAnnotation.services.ProductService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class myClass {

    @Bean
    public ProductService productService()
    {
        return new ProductService();
    }
}
