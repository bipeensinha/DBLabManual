package com.example.demoAnnotation;

import com.example.demoAnnotation.services.ProductService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class DemoAnnotationApplication {

	public static void main(String[] args) {

	ConfigurableApplicationContext context= SpringApplication.run(DemoAnnotationApplication.class, args);
		ProductService productService = context.getBean(ProductService.class);
		System.out.println(productService);
		productService.createProduct();
	}

}
