package com.example.demoAnnotation.services;

public class ProductService {
    public void createProduct()
    {
        System.out.println("Creating Product");
    }
}
